
<div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <input wire:model="search" type="text" placeholder="Search users..."/>

    <ul>
        <?php echo e($results); ?>


    </ul>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</div>
<?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/livewire/filter-cursos.blade.php ENDPATH**/ ?>