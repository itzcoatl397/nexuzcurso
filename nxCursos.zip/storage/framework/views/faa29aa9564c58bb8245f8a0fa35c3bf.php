<?php $__env->startSection('contenido'); ?>

<?php $__currentLoopData = $reconocimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reconocimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div>
    <p>Fondo</p>

<img src="<?php echo e(asset($reconocimiento->image_path_fondo)); ?>" alt="" srcset="" width="300" height="300">


</div>
<div>
    <p>pie </p>

<img src="<?php echo e(asset($reconocimiento->image_path_pie)); ?>" alt="" srcset="" width="300" height="300">


</div>
<div>
    <p>encabezado</p>

<img src="<?php echo e(asset($reconocimiento->image_path_encabezado)); ?>" alt="" srcset="" width="300" height="300">


</div>
<div>
    <h3>texto 1</h3>
    <p><?php echo e($reconocimiento->texto1); ?></p>
    <h3>texto 2</h3>

    <p><?php echo e($reconocimiento->texto2); ?></p>
    <h3>texto 3</h3>

    <p><?php echo e($reconocimiento->texto3); ?></p>
    <h3>texto 4</h3>

    <p><?php echo e($reconocimiento->texto4); ?></p>
    <h3>texto 5</h3>

    <p><?php echo e($reconocimiento->texto5); ?></p>


</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/vista_previa.blade.php ENDPATH**/ ?>