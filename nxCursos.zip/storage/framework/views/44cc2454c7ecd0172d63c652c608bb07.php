<div>
    <?php $__currentLoopData = $altaCursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altaCurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($altaCurso->visible == 1): ?>

    <td scope="row"><?php echo e($altaCurso->nombre_curso); ?></td>
    <td scope="row"><?php echo e($altaCurso->descripcion_curso); ?></td>

    <td> <img src="<?php echo e(asset($altaCurso->image_path)); ?>" width="200" alt=""
            srcset=""></td>
    <td>


        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($categoria->id == $altaCurso->categoria_id): ?>
                <option value="<?php echo e($categoria->id); ?>" selected>
                    <?php echo e($categoria->nombre_categoria); ?>

                </option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/cursos/cursos.blade.php ENDPATH**/ ?>