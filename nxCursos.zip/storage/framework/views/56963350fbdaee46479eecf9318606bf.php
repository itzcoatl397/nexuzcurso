<div class="table-responsive mt-8 p-5">
            <br>
            <table class="table table-striped
    table-hover
    table-borderless
    table-primary
    align-middle p-2">
                <thead class="table-light">

                    <tr>
                        <th> Nombre Curso</th>
                        <th>Descripcion</th>
                        <th>Imagenes </th>
                        <th>Categoria </th>


                        <th>Acciones </th>
                        <th>Visibilidad </th>
                        <th>temas </th>


                    </tr>
                </thead>
                <tbody class="table-group-divider">


                    <?php $__currentLoopData = $altaCursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altaCurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td scope="row"><?php echo e($altaCurso->nombre_curso); ?></td>
                            <td scope="row"><?php echo e($altaCurso->descripcion_curso); ?></td>

                            <td> <img src="<?php echo e(asset($altaCurso->image_path)); ?>" width="200" alt=""
                                    srcset=""></td>
                            <td>


                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($categoria->id == $altaCurso->categoria_id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected>
                                            <?php echo e($categoria->nombre_categoria); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                            </td>

                            <td scope="row">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#actualizarModal<?php echo e($altaCurso->id); ?>">
                                    Actualizar
                                </button>

                                <form action="<?php echo e(route('controlCursos.delete_Cursos', ['id' => $altaCurso->id])); ?> "
                                    method="post">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            </td>

                            <td>
                                <form action="" >


                                    <input type="hidden" class="id_curso" value="<?php echo e($altaCurso->id); ?>">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input flexSwitchCheckDefault" type="checkbox" role="switch" value="1" <?php echo e($altaCurso->visible == 1 ? 'checked' : ''); ?>

                                            >

                                    </div>
                                </form>
                            </td>

                            <td>     <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#addTemas<?php echo e($altaCurso->id); ?>">
                                Temas
                            </button></td>
                        </tr>

                        <div class="modal fade" id="actualizarModal<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Editar Curso</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('controlCursos.update_cursos', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Nombre Categoria</label>
                                                <input type="text" class="form-control" name="nombre"
                                                    value="<?php echo e($altaCurso->nombre_curso); ?>"
                                                    placeholder="Ingrese el nombre">
                                            </div>
                                            <div class="mb-3">
                                                <label for="descripcion" class="form-label">Descripción</label>
                                                <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"><?php echo e($altaCurso->descripcion_curso); ?></textarea>
                                            </div>
                                            <div class="mb-3">
                                                <img width="300" src="<?php echo e(asset($altaCurso->image_path)); ?>"
                                                    srcset="">
                                                <br>
                                                <label for="featured" class="form-label">Imagen</label>
                                                <input type="file" class="form-control" name="featured">
                                            </div>
                                            <input type="submit" class="btn btn-primary" value="Actualizar">
                                        </form>


                                    </div>

                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="addTemas<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Temas</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('temas-curso', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Nombre tema</label>
                                                <input type="text" class="form-control" name="nombre_tema"

                                                    placeholder="Ingrese el nombre">
                                            </div>
                                            <div class="mb-3">
                                                <label for="descripcion" class="form-label">Descripción</label>
                                                <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"></textarea>
                                            </div>

                                            <input type="submit" class="btn btn-primary" value="añadir">
                                        </form>
                                       <div class="mt-2">
                                        <h1 class="" style="font-size: 30px;  text-transform: capitalize;">Tus  temas </h1>
                                        <?php
                                        $found = false; // Initialize the flag variable
                                        ?>


                                        <?php $__currentLoopData = $temasCursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temaCurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($temaCurso->curso_id == $altaCurso->id): ?>
                                                <a href=""><?php echo e($temaCurso->nombre_tema); ?></a>
                                                <?php
                                                $found = true; // Set the flag to true when a matching record is found
                                                ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$found): ?>
                                        <p>No tienes temas asignados</p>
                                    <?php endif; ?>



                                       </div>
                                    </div>

                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>


<?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/cursos/tables_cursos.blade.php ENDPATH**/ ?>