<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- En el head -->

  
<script src="<?php echo e(asset('js')); ?>"></script>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

<?php echo $__env->yieldPushContent('styles'); ?>

</head>
</head>
<body>

<header>

    <?php if(auth()->guard()->check()): ?>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Nexus Cursos</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
            <p> Hola <?php echo e(auth()->user()->username); ?></p>
              </li>
              <li class="nav-item">
                <a class="nav-link active"       href="<?php echo e(route('dashboard.index')); ?>">Home</a>
                  </li>
              <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('dashboard.controlCursos')); ?>"> control de cursos</a>
                <br>
                <a class="nav-link active" href="<?php echo e(route('dashboard.altaUsuario')); ?>"> control usuarios</a>

                  </li>

              <li class="nav-item">

                <form action="<?php echo e(route('logout-universal')); ?>" method="POST">

                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn">Cerrar sesion </button>
                </form>
              </li>



            </ul>
          </div>
        </div>
      </nav>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Nexus Cursos</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('login')); ?>"">Login</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('register')); ?>">Registro</a>
              </li>



            </ul>
          </div>
        </div>
      </nav>
    <?php endif; ?>
</header>

<main>
  <div class="flex">
    <?php echo $__env->yieldContent('contenido'); ?>

  </div>
  <?php echo $__env->yieldContent('contenido_info2'); ?>

 <div class="grid col-6">
    <?php echo $__env->yieldContent('contenido_info'); ?>
 </div>

</main>

<?php echo $__env->yieldPushContent('scripts'); ?>
<script>

    $(function () {
        $('select').selectpicker();
    });
    </script>
</body>
</html>
<?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/layout/app.blade.php ENDPATH**/ ?>