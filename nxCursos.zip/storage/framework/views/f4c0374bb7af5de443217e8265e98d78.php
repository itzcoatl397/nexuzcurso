 <div class="table-responsive mt-8 p-5">
            <br>
            <table class="table table-striped
    table-hover
    table-borderless
    table-primary
    align-middle p-2">
                <thead class="table-light">

                    <tr>
                        <th> Nombre Curso</th>
                        <th>Descripcion</th>
                        <th>Imagenes </th>
                        <th>Categoria </th>


                        <th>Acciones </th>
                        <th>Visibilidad </th>
                        <th>temas </th>
                        <th>Acciones </th>



                    </tr>
                </thead>
                <tbody class="table-group-divider">


                    <?php $__currentLoopData = $altaCursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altaCurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td scope="row"><?php echo e($altaCurso->nombre_curso); ?></td>
                            <td scope="row"><?php echo e($altaCurso->descripcion_curso); ?></td>

                            <td> <img src="<?php echo e(asset($altaCurso->image_path)); ?>" width="200" alt=""
                                    srcset=""></td>
                            <td>


                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($categoria->id == $altaCurso->categoria_id): ?>
                                        <option value="<?php echo e($categoria->id); ?>" selected>
                                            <?php echo e($categoria->nombre_categoria); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                            </td>

                            <td scope="row">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#actualizarModal<?php echo e($altaCurso->id); ?>">
                                    Actualizar
                                </button>

                                <form action="<?php echo e(route('controlCursos.delete_Cursos', ['id' => $altaCurso->id])); ?> "
                                    method="post">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            </td>

                            <td>
                                <form action="" >


                                    <input type="hidden" class="id_curso" value="<?php echo e($altaCurso->id); ?>">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input flexSwitchCheckDefault" type="checkbox" role="switch" value="1" <?php echo e($altaCurso->visible == 1 ? 'checked' : ''); ?>

                                            >

                                    </div>
                                </form>
                            </td>

                            <td>     <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#addTemas<?php echo e($altaCurso->id); ?>">
                                Temas
                            </button></td>



                            <td>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#reconocimiento<?php echo e($altaCurso->id); ?>"> Reconocimiento
                            </td>

                            <td>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#terminacion<?php echo e($altaCurso->id); ?>"> Terminacion
                            </td>
                            <td>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#puntos<?php echo e($altaCurso->id); ?>"> Puntos
                            </td>
                        </tr>

                        <div class="modal fade" id="actualizarModal<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Editar Curso</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('controlCursos.update_cursos', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Nombre Categoria</label>
                                                <input type="text" class="form-control" name="nombre"
                                                    value="<?php echo e($altaCurso->nombre_curso); ?>"
                                                    placeholder="Ingrese el nombre">
                                            </div>
                                            <div class="mb-3">
                                                <label for="descripcion" class="form-label">Descripción</label>
                                                <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"><?php echo e($altaCurso->descripcion_curso); ?></textarea>
                                            </div>
                                            <div class="mb-3">
                                                <img width="300" src="<?php echo e(asset($altaCurso->image_path)); ?>"
                                                    srcset="">
                                                <br>
                                                <label for="featured" class="form-label">Imagen</label>
                                                <input type="file" class="form-control" name="featured">
                                            </div>
                                            <input type="submit" class="btn btn-primary" value="Actualizar">
                                        </form>


                                    </div>



                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="addTemas<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Temas</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('temas-curso', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Nombre tema</label>
                                                <input type="text" class="form-control" name="nombre_tema"

                                                    placeholder="Ingrese el nombre">
                                            </div>
                                            <div class="mb-3">
                                                <label for="descripcion" class="form-label">Descripción</label>
                                                <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"></textarea>
                                            </div>

                                            <input type="submit" class="btn btn-primary" value="añadir">
                                        </form>
                                       <div class="mt-2">
                                        <h1 class="" style="font-size: 30px;  text-transform: capitalize;">Tus  temas </h1>
                                        <?php
                                        $found = false; // Initialize the flag variable
                                        ?>


                                        <?php $__currentLoopData = $temasCursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temaCurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($temaCurso->curso_id == $altaCurso->id): ?>
                                                <div class="row p-2">
                                                    <a href="<?php echo e(route('temas-editar', $temaCurso->id )); ?>"   class="link-offset-2 link-underline link-underline-opacity-0" ><?php echo e($temaCurso->nombre_tema); ?></a>
                                                </div>
                                                <?php
                                                $found = true; // Set the flag to true when a matching record is found
                                                ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$found): ?>
                                        <p>No tienes temas asignados</p>
                                    <?php endif; ?>



                                       </div>
                                    </div>

                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="reconocimiento<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">reconocimiento</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('reconocimiento', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Imagen de  fondo</label>
                                             <input type="file"  class="form-control" name="fondo" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Imagen de  Pie de  pagina</label>
                                             <input type="file"  class="form-control" name="pie_pagina" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Imagen de  Encabezado</label>
                                             <input type="file"  class="form-control" name="encabezado" id="">
                                            </div>

                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 1 </label>
                                             <input type="text"  class="form-control" name="text_1" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 2 </label>
                                             <input type="text"  class="form-control" name="text_2" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 3 </label>
                                             <input type="text"  class="form-control" name="text_3" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 4 </label>
                                             <input type="text"  class="form-control" name="text_4" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 5 </label>
                                             <input type="text"  class="form-control" name="text_5" id="">
                                            </div>
                                            <input type="submit" class="btn btn-primary" value="Actualizar">
                                        </form>



                                        <?php
                                        $found = false; // Initialize the flag variable
                                        ?>


                                        <?php $__currentLoopData = $reconocimiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($recon->curso_id == $altaCurso->id): ?>
                                                <div class="row p-2">

                                                </div>
                                                <?php
                                                $found = true; // Set the flag to true when a matching record is found
                                                ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$found): ?>
                                        <p>No tienes temas asignados</p>
                                    <?php endif; ?>


                                    </div>



                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="terminacion<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Editar Curso</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('terminar', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 1 </label>
                                             <input type="text"  class="form-control" name="text_1" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 2 </label>
                                             <input type="text"  class="form-control" name="text_2" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Texto 3 </label>
                                             <input type="text"  class="form-control" name="text_3" id="">
                                            </div>
                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Imagen </label>
                                             <input type="file"  class="form-control" name="fondo" id="">
                                            </div>

                                            <input type="submit" class="btn btn-primary" value="Actualizar">
                                        </form>


                                        <?php
                                        $found = false; // Initialize the flag variable
                                        ?>


                                        <?php $__currentLoopData = $terminacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($termi->curso_id == $altaCurso->id): ?>
                                                <div class="row p-2">
                                                    <a href="<?php echo e(route('vista-previa2', $termi->id )); ?>"   class="link-offset-2 link-underline link-underline-opacity-0" >Vista Previa</a>
                                                </div>
                                                <?php
                                                $found = true; // Set the flag to true when a matching record is found
                                                ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$found): ?>
                                        <p>No tienes temas asignados</p>
                                    <?php endif; ?>
                                    </div>



                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="modal fade" id="puntos<?php echo e($altaCurso->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <!-- Encabezado del modal -->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Puntos  Humanizate</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <!-- Cuerpo del modal -->
                                    <div class="modal-body">
                                        <form
                                            action="<?php echo e(route('puntos', ['id' => $altaCurso->id])); ?>"
                                            method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <div class="mb-3">
                                                <label for="nombre" class="form-label">Puntos </label>
                                             <input type="text"  class="form-control" name="puntos" id="">
                                            </div>



                                            <input type="submit" class="btn btn-primary" value="Actualizar">
                                        </form>


                                        <?php
                                        $found = false; // Initialize the flag variable
                                        ?>


                                        <?php $__currentLoopData = $terminacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($termi->curso_id == $altaCurso->id): ?>
                                                <div class="row p-2">
                                                    <a href="<?php echo e(route('vista-previa2', $termi->id )); ?>"   class="link-offset-2 link-underline link-underline-opacity-0" >Vista Previa</a>
                                                </div>
                                                <?php
                                                $found = true; // Set the flag to true when a matching record is found
                                                ?>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$found): ?>
                                        <p>No tienes temas asignados</p>
                                    <?php endif; ?>
                                    </div>



                                    <!-- Pie del modal -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>
<?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/controlCursos/tables_cursos.blade.php ENDPATH**/ ?>