<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AltaNuevoUsuario">
        Alta de usuario
    </button>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AltaNuevoIdioma">
        Alta de Idioma
    </button>

    <div class="modal fade" id="AltaNuevoUsuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Alta de nuevo curso</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action='<?php echo e(route('dashboard.crear')); ?>' enctype="multipart/form-data" method="post">

                        <?php echo csrf_field(); ?>

                        <div>
                            <label for="">Nombre</label>
                            <input type="text" name="nombre" class="form-control">
                        </div>
                        <div>
                            <label for="">Correo</label>
                            <input type="email" name="correo" class="form-control">
                        </div>
                        <div>
                            <label for="">Contraseña</label>
                            <input type="password" name="password" class="form-control">
                        </div>
                        <div>
                            <label for="">Telefono</label>
                            <input type="text" name="telefono" class="form-control">
                        </div>
                        <div>
                            <select class="form-select" data-live-search="true" name="pais" id="">

                                <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pais->nombre); ?>" class="form-control"> <?php echo e($pais->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mt-2">
                            <select class="form-select mt-2" data-live-search="true" name="idioma" id="">

                                <?php $__currentLoopData = $idiomas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idioma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($idioma->nombre); ?>" class="form-control"> <?php echo e($idioma->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Texto 1 </label>
                            <input type="text" class="form-control" name="text_1" id="">
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Texto 2 </label>
                            <input type="text" class="form-control" name="text_2" id="">
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Texto 3 </label>
                            <input type="text" class="form-control" name="text_3" id="">
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Texto 4 </label>
                            <input type="text" class="form-control" name="text_4" id="">
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Texto 5 </label>
                            <input type="text" class="form-control" name="text_5" id="">
                        </div>


                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="activo" name="estado[]" value="1">
                            <label class="form-check-label" for="activo">Activo</label>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="inactivo" name="estado[]"
                                value="0">
                            <label class="form-check-label" for="inactivo">Inactivo</label>
                        </div>

                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </form>

                </div>

            </div>
        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('contenido_info'); ?>
        <div class="modal fade" id="AltaNuevoIdioma" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Alta de nuevo curso</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action='<?php echo e(route('dashboard.crearIdioma')); ?>' enctype="multipart/form-data" method="post">

                            <?php echo csrf_field(); ?>

                            <div>
                                <label for="">Nombre de idioma</label>
                                <input type="text" name="idioma" class="form-control">
                            </div>

                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-primary">Guardar cambios</button>
                        </form>

                    </div>

                </div>
            </div>
        <?php $__env->stopSection(); ?>


        <?php $__env->startSection('contenido_info2'); ?>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <hr>

                <p>Nombre <?php echo e($usuario->name); ?></p>
                <p>Correo <?php echo e($usuario->email); ?></p>
                <p>Pais <?php echo e($usuario->pais); ?></p>

                <h1>Tus Cursos </h1>

                <?php $__currentLoopData = $curso_asignado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($curso->user_id == $usuario->id): ?>
                        <p><?php echo e($curso->nombre_curso); ?></p>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#modalEncuesta<?php echo e($curso->curso_id); ?>">
                            Encuesta
                        </button>
                        <br>
                        <br>
                    <?php endif; ?>


                    <div class="modal fade" id="modalEncuesta<?php echo e($curso->curso_id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalLabel<?php echo e($curso->curso_id); ?>">Asignar Curso</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Aquí puedes agregar un formulario para actualizar los datos del usuario -->
                                    <!-- Por ejemplo, campos para editar nombre, correo y país -->
                                    <form  method="post"  action="<?php echo e(route('dashboard.encuesta',['id'=>$curso->curso_id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="calificacion">¿Cómo calificas este curso?</label>
                                            <select class="form-control" id="calificacion" name="calificacion">
                                              <option value="1">1 - Muy malo</option>
                                              <option value="2">2 - Malo</option>
                                              <option value="3">3 - Regular</option>
                                              <option value="4">4 - Bueno</option>
                                              <option value="5">5 - Excelente</option>
                                            </select>
                                          </div>
                                          <div class="form-group">
                                            <label>¿Recomendarías este curso a un amigo?</label>
                                            <div class="form-check">
                                              <input class="form-check-input" type="radio" name="recomendar" id="recomendarSi" value="si">
                                              <label class="form-check-label" for="recomendarSi">
                                                Sí
                                              </label>
                                            </div>
                                            <div class="form-check">
                                              <input class="form-check-input" type="radio" name="recomendar" id="recomendarNo" value="no">
                                              <label class="form-check-label" for="recomendarNo">
                                                No
                                              </label>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label>¿Te interesa tomar otro curso con nosotros?</label>
                                            <div class="form-check">
                                              <input class="form-check-input" type="radio" name="interesOtroCurso" id="interesSi" value="si">
                                              <label class="form-check-label" for="interesSi">
                                                Sí
                                              </label>
                                            </div>
                                            <div class="form-check">
                                              <input class="form-check-input" type="radio" name="interesOtroCurso" id="interesNo" value="no">
                                              <label class="form-check-label" for="interesNo">
                                                No
                                              </label>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label for="comentario">Si te gustó el curso, deja tu comentario</label>
                                            <textarea class="form-control" id="comentario" name="comentario" rows="3"></textarea>
                                          </div>
                                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        </div>








                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                    data-bs-target="#modalActualizar<?php echo e($usuario->id); ?>">
                    Configuracion
                </button>

                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                    data-bs-target="#modalAsignacion<?php echo e($usuario->id); ?>">
                    Asignación de cursos
                </button>
                <div class="modal fade" id="modalActualizar<?php echo e($usuario->id); ?>" tabindex="-1"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalLabel<?php echo e($usuario->id); ?>">Actualizar Usuario</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <!-- Aquí puedes agregar un formulario para actualizar los datos del usuario -->
                                <!-- Por ejemplo, campos para editar nombre, correo y país -->
                                <form method="post"
                                    action="<?php echo e(route('dashboard.altaUsuario.update', ['id' => $usuario->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group">
                                        <label for="nombre">Nombre:</label>
                                        <input type="text" name="nombre" class="form-control"
                                            value="<?php echo e($usuario->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Correo:</label>
                                        <input type="email" name="correo" class="form-control"
                                            value="<?php echo e($usuario->email); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="telefono">Telefono:</label>
                                        <input type="text" name="telefono" class="form-control"
                                            value="<?php echo e($usuario->telefono); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" class="form-control"
                                            value="<?php echo e($usuario->password); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="nombre" class="form-label">Texto 1 </label>
                                        <input type="text" class="form-control" name="text_1" id=""
                                            value="<?php echo e($usuario->texto1); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nombre" class="form-label">Texto 2 </label>
                                        <input type="text" class="form-control" name="text_2" id=""
                                            value="<?php echo e($usuario->texto2); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nombre" class="form-label">Texto 3 </label>
                                        <input type="text" class="form-control" name="text_3" id=""
                                            value="<?php echo e($usuario->texto3); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nombre" class="form-label">Texto 4 </label>
                                        <input type="text" class="form-control" name="text_4" id=""
                                            value="<?php echo e($usuario->texto4); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nombre" class="form-label">Texto 5 </label>
                                        <input type="text" class="form-control" name="text_5" id=""
                                            value="<?php echo e($usuario->texto5); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="pais">Pais:</label>

                                        <select class="form-select" data-live-search="true" name="pais">
                                            <option value="<?php echo e($usuario->pais); ?>" class="form-control">
                                                <?php echo e($usuario->pais); ?></option>

                                            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pais->nombre !== $usuario->pais): ?>
                                                    <option value="<?php echo e($pais->nombre); ?>" class="form-control">
                                                        <?php echo e($pais->nombre); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="pais">Idioma:</label>

                                        <select class="form-select" data-live-search="true" name="idioma">
                                            <option value="<?php echo e($usuario->idioma); ?>" class="form-control">
                                                <?php echo e($usuario->idioma); ?></option>

                                            <?php $__currentLoopData = $idiomas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idioma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($idioma->nombre !== $usuario->idioma): ?>
                                                    <option value="<?php echo e($idioma->nombre); ?>" class="form-control">
                                                        <?php echo e($idioma->nombre); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="activo" name="estado[]"
                                            value="1"<?php echo e($usuario->status == 1 ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="activo">Activo</label>
                                    </div>

                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="inactivo" name="estado[]"
                                            value="0"<?php echo e($usuario->status == '0' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="inactivo">Inactivo</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="modalAsignacion<?php echo e($usuario->id); ?>" tabindex="-1"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalLabel<?php echo e($usuario->id); ?>">Asignar Curso</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <!-- Aquí puedes agregar un formulario para actualizar los datos del usuario -->
                                <!-- Por ejemplo, campos para editar nombre, correo y país -->
                                <form method="post" action="<?php echo e(route('dashboard.asignarCurso')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">

                                        <input type="hidden" name="user_id" class="form-control"
                                            value="<?php echo e($usuario->id); ?>">
                                    </div>



                                    <div class="form-group">
                                        <label for="fecha"> fecha de vigencia :</label>
                                        <input type="date" name="fecha" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label for="pais">Cursos:</label>
                                        <select class="form-select" name="curso_id" id="">
                                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($curso->id); ?>" class="form-control">
                                                    <?php echo e($curso->nombre_curso); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="col">
                <?php echo e($usuarios->links()); ?>

            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/altaUsuario.blade.php ENDPATH**/ ?>