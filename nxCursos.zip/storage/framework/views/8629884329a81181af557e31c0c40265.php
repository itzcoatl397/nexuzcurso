<?php $__env->startSection('contenido'); ?>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AltaCategorías">
        Alta de categorías
    </button>


    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AltaNuevoCurso">
        Alta de nuevo curso
    </button>


    <div class="p-2 ">
        <form action="<?php echo e(route('filtro-categoria')); ?>" method="POST">
<?php echo csrf_field(); ?>
            <select name="categoria_id" id="" class="form-select">
                <option class="form-control" value="">Todos</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option class="form-control" value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre_categoria); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="submit" value="buscar" class="btn bg-success " style="color: white;font-weight: 700 ;text-transform: uppercase;padding: 2px auto; margin-top: 5px;width: 100%">
        </form>
    </div>

    <div class="modal fade" id="AltaCategorías" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel"> Alta de categorías</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form enctype="multipart/form-data" class="" method="POST"
                        action="   <?php echo e(route('dashboard.controlCursos.alta')); ?>  ">

                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre Categoria</label>
                            <input type="text" class="form-control" name="nombre" placeholder="Ingrese el nombre ">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3">
                            <label for="descripcion" class="form-label">Descripción</label>
                            <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="featured" class="form-label">Imagen</label>
                            <input type="file" class="form-control" name="featured" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-primary">Guardar cambios</button>
                        </div>
                    </form>



                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('dashboard.controlCursos.update', ['id' => $categoria->id])); ?>"
                            method="post" enctype="multipart/form-data">


                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre Categoria</label>
                                <input type="text" class="form-control" name="nombre"
                                    value="<?php echo e($categoria->nombre_categoria); ?>" placeholder="Ingrese el nombre ">
                            </div>
                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"><?php echo e($categoria->descripcion_categoria); ?></textarea>
                            </div>
                            <div class="mb-3">

                                <img width="300" src="<?php echo e(asset($categoria->image_path)); ?>" srcset="">
                                <br>
                                <label for="featured" class="form-label">Imagen</label>
                                <input type="file" class="form-control" name="featured">
                            </div>

                            <input type="submit" class="btn btn-primary" value="Actuaizar">





                        </form>
                        <form action="<?php echo e(route('dashboard.controlCursos.delete', ['id' => $categoria->id])); ?> "
                            method="post">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>

                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal  ALTA DE  CURSOS-->
    <div class="modal fade" id="AltaNuevoCurso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Alta de nuevo curso</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action='/dashboard/controlCursos/altaCursos' enctype="multipart/form-data" method="post">

                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control" name="nombre_curso"
                                placeholder="Ingrese el nombre">
                        </div>
                        <div class="mb-3">
                            <label for="descripcion" class="form-label">Descripción</label>
                            <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese la descripción"></textarea>
                        </div>

                        <select name="categoria_id" id="" class="form-select">
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="form-control" value="<?php echo e($categoria->id); ?>">
                                    <?php echo e($categoria->nombre_categoria); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                        <div class="mb-3">
                            <label for="featured" class="form-label">Imagen</label>
                            <input type="file" class="form-control" name="featured">
                        </div>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </form>

                </div>

            </div>
        </div>


        <?php $__env->startSection('contenido_info2'); ?>
        <?php echo $__env->make('controlCursos.tables_cursos', ['altaCursos' => $altaCursos,'reconocimiento'=>$reconocimiento,'terminacion'=>$terminacion], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <?php $__env->stopSection(); ?>
     <?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

        <script src="<?php echo e(asset('js/visible.js')); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js"></script>

    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gerar\Documents\nexuz\nxCursos\resources\views/controlCursos.blade.php ENDPATH**/ ?>